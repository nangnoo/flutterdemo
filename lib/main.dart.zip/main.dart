import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Title',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: Register(),
    );
  }
}

class Register extends StatefulWidget {
  Register({Key key}) : super(key: key);

  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  PickedFile imageFile;

  Widget displayAvatar() {
    return Container(
        padding: EdgeInsets.all(20),
        width: MediaQuery.of(context).size.width * 0.5,
        height: MediaQuery.of(context).size.height * 0.5,
        child: imageFile == null
            ? Image.asset('assets/images/avatar.png')
            : Image.file(File(imageFile.path)));
  }

  Future<void> selectImage(ImageSource imageSource) async {
    try {
      var pickedFile = await ImagePicker().getImage(
        source: imageSource,
        maxWidth: 300,
        maxHeight: 300,
      );
      setState(() {
        imageFile = pickedFile;
      });
    } catch (e) {
      print(e);
    }
  }

  Widget btnSelectImage() {
    return IconButton(
        icon: Icon(
          Icons.image,
          color: Colors.indigo.shade800,
          size: 40.0,
        ),
        onPressed: () {
          selectImage(ImageSource.gallery);
        });
  }

  Widget btnSelectCamera() {
    return IconButton(
        icon: Icon(
          Icons.camera_alt,
          color: Colors.indigo.shade800,
          size: 40.0,
        ),
        onPressed: () {
          selectImage(ImageSource.camera);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              displayAvatar(),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  btnSelectCamera(),
                  btnSelectImage(),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
